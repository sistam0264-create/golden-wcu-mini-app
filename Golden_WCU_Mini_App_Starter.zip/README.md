# Golden WCU Freshman Tutorial — Telegram Mini App

This is a starter frontend for a Telegram Mini App.

## Files
- index.html — app structure
- style.css — design
- app.js — Telegram integration and interactions

## Important
The app currently uses demo content. Before publishing real premium materials, add a secure backend and validate Telegram `initData` on the server. Do not put your Telegram bot token in these frontend files.

## Publish
Upload these files to an HTTPS web host, then give the HTTPS URL to BotFather when configuring the Mini App.

Official Telegram docs:
https://core.telegram.org/bots/webapps
